#include<iostream>
#include<chrono>
#include<vector>
#include<cstdlib>
#include<ctime>
#include "RECORD_AVL.h"
#include "RECORD_BST.h"
#include "RECORD_BTREE.h"

using namespace std;
using namespace std::chrono;

string getRandomName(){
    string s;
    s.push_back((char)('A' + rand()%26));
    s.push_back((char)('A' + rand()%26));
    s.push_back((char)('A' + rand()%26));
    s.push_back((char)('A' + rand()%26));
    cout<<s<<endl;
}

Record getDummyRecord(){
    Record rec;
    int id = rand() % 50001;
    int age = rand() % 100;
    // string name = getRandomName();

    rec.id = id;
    rec.age = age;
    rec.name = "dfsd";

    return rec;
}

int main(){
    srand(time(NULL));
    AVL *avl_table = new AVL();
    BST *bst_table = new BST();
    BTree *btree_table = new BTree(3);
    vector<int> avg_times;
    auto start = high_resolution_clock::now();
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);

    int record_size = 1000;

    // inserting 1000 records in AVL
    start = high_resolution_clock::now();
    
    for(int i=0;i<record_size;i++){
        Record rec = getDummyRecord();
        avl_table->insert(rec);
    }

    stop = high_resolution_clock::now();

    duration = duration_cast<microseconds>(stop - start);

    avg_times.push_back(duration.count()/record_size);

    // inserting 1000 records in bst
    start = high_resolution_clock::now();
    
    for(int i=0;i<record_size;i++){
        bst_table->insert(getDummyRecord());
    }

    stop = high_resolution_clock::now();

    duration = duration_cast<microseconds>(stop - start);

    avg_times.push_back(duration.count()/record_size);

    // inserting 1000 records in btree
    start = high_resolution_clock::now();
    
    for(int i=0;i<record_size;i++){
        btree_table->insert(getDummyRecord());
    }

    stop = high_resolution_clock::now();

    duration = duration_cast<microseconds>(stop - start);

    avg_times.push_back(duration.count()/record_size); 

    cout<<record_size<<" records: "<<endl;
    cout<<"Inserting time of AVL: "<<avg_times[0]<<endl;
    cout<<"Inserting time of BST: "<<avg_times[1]<<endl;
    cout<<"Inserting time of BTREE: "<<avg_times[2]<<endl;






}